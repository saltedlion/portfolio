#-*-coding: utf-8 -*-

#Import Modules
import os, pygame, time
from pygame.locals import *
from pygame.compat import geterror
from lib import *
from playerData import *

class Face(pygame.sprite.Sprite):
	def __init__(self, path):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image(path, -1)
		
		#적절하게 크기조절
		#pos : 285, 405
		#size : 69 * 75
		self.image = pygame.transform.scale(self.image, (55, 75))
		newpos = self.rect.move(295, 405)
		self.rect = newpos
		
	def update(self):
		pass

				
class Chainsaw(pygame.sprite.Sprite):
	def __init__(self):
		pygame.sprite.Sprite.__init__(self)
	
		self.chainsaw, self.rect = load_image('img/player/SAWGA0.png', -1)
		self.sound = load_sound('wav/saw/DSSAWFUL.wav')
		self.posList = []
		self.visible = False
		self.soundstart = False
	
	def slashStart(self, x, y):
		pass
	
	def slashMove(self, x, y):
		self.visible = True
		self.posList.append((x, y))
		
		if self.soundstart == False:
			self.soundstart = True
			self.sound.play(1000);
		
	def slashEnd(self, x, y):
		self.visible = False
		self.posList = []
		
		self.soundstart = False
		self.sound.stop()
		
	def draw(self, surface):
		prevPos = None
		for pos in self.posList:
			if prevPos != None:
				pygame.draw.line(surface, (255, 0, 0), prevPos, pos, 3)
			prevPos = pos
		
		pos = self.posList[-1]
		rect = Rect(pos[0]-100, pos[1], self.rect.width, self.rect.height)
		surface.blit(self.chainsaw, rect)
	
	def update(self):
		pass 

				
class Punch(pygame.sprite.Sprite):
	def __init__(self):
		pygame.sprite.Sprite.__init__(self)
		
		#animation효과를 내기 위해서 공격모션 3장 로딩
		img0, self.rect = load_image('img/player/PUNGB0.png', -1)
		img1, self.rect = load_image('img/player/PUNGC0.png', -1)
		img2, self.rect = load_image('img/player/PUNGD0.png', -1)
		
		self.animation = [img0, img1, img2]
		self.cnt = 0
		
		self.sound = load_sound('wav/punch/DSPUNCH.wav')
		self.visible = False
		
		#몇 프레임마다 스프라이트를 교체할것인가
		self.range = 7
		
	def getSprite(self):
		sprite = self.animation[self.cnt/self.range]
		self.cnt = self.cnt % (len(self.animation)*self.range)
		return sprite
	
	def update(self):
		self.cnt = self.cnt + 1
		if self.cnt >= len(self.animation)*self.range:
			self.visible = False
	
	def setGrid(self, row, col):
		if row < 0 or col < 0:
			self.visible = False
			x = -1000
			y = -1000
			return
		
		self.visible = True
		self.cnt = 0
		if row == 0:
			y = 0
		elif row == 1:
			y = 136
		elif row == 2:
			y = 272

		if col == 0:
			x = 0
		elif col == 1:
			x = 216
		elif col == 2:
			x = 422
			
		width = self.rect.width
		height = self.rect.height
		self.rect = pygame.Rect(x+30, y+40, width, height)

	def setVisible(self, visible):
		self.visible = visible
				
class Player:
	def __init__(self, grid):
		self.hp = PlayerData.playerMaxHp
		self.mp = 50
		
		self.grid = grid
		
		#load face
		self.face = [
					 Face('img/face/face1.gif'),
					 Face('img/face/face2.gif'),
					 Face('img/face/face3.gif'),
					 Face('img/face/face4.gif'),
					 Face('img/face/face5.gif'),
					 Face('img/face/die.png')
					 ]
		self.punch = Punch()
		self.chainsaw = Chainsaw()
		
	
		self.diesound = load_sound('wav/player_die/DSPLDETH.wav')
		self.hitsound = load_sound('wav/player_die/DSPDIEHI.wav')
		
		#마지막으로 mp 올린 시간. 이걸로 1초마다 올라가는걸 잰다
		self.lastMpUpTime = time.time()
	
	def canAttack(self):
		if self.hp <= 0:
			return False
		else:
			return True	
	
	def attacked(self, damage):
		self.hp = self.hp - damage
		if self.hp < 0:
			self.hp = 0
		#적절한 소리 재생
		
		if self.hp == 0:
			if self.diesound != None:
				self.diesound.play()
				self.diesound = None
		else:
			self.hitsound.play()
	
	def getFace(self):
		if self.hp < 0:
			self.hp = 0
		index = (100-self.hp) / 20
		return self.face[index]
	
	def draw(self, surface):
		#hp 찍기
		#if pygame.font:
		font = pygame.font.Font(None, 54)
		text = font.render("%3d" % self.hp, 1, (255, 0, 0))
		textpos = pygame.Rect(115, 413, 76, 42)
		surface.blit(text, textpos)
		
		#mp
		font = pygame.font.Font(None, 54)
		text = font.render("%3d" % self.mp, 1, (255, 0, 0))
		textpos = pygame.Rect(15, 413, 76, 42)
		surface.blit(text, textpos)
		
		#punch
		if self.punch.visible == True:
			punchSprite = self.punch.getSprite()
			surface.blit(punchSprite, self.punch.rect)
			
		#chainsaw
		if self.chainsaw.visible == True:
			self.chainsaw.draw(surface)
	
	def update(self):
		self.punch.update()
		self.chainsaw.update()
		
		#1초마다 용자력 증가
		now = time.time()
		if now - self.lastMpUpTime > 1:
			self.mp = self.mp + PlayerData.playerMpPerSecond
			self.lastMpUpTime = now	
			
	def stab(self, row, col):
		if self.canAttack() == False:
			return
		
		if row < 0 or col < 0:
			return
		
		self.punch.sound.stop()
		self.punch.setGrid(row, col);
		self.punch.sound.play()
		
		#해당 위치에 있는 몹의 hp깎기
		mon = self.grid.get(row, col)
		if mon != None:
			mon.stabbed()
	
	def slashStart(self, x, y):
		if self.canAttack() == False:
			return
		
		self.chainsaw.slashStart(x, y);
		self.chainStartTime = time.time()		
	
	def slashMove(self, x, y):
		if self.canAttack() == False:
			return
		
		if self.mp < PlayerData.slashMpUsePerSecond:
			self.slashEnd(x, y)
			return
			
		self.chainsaw.slashMove(x, y);
		
		#적에게 뎀지 넣기
		mon = self.grid.get(self.grid.getRow(y), self.grid.getCol(x))
		if mon != None:
			mon.slashed()
			
		now = time.time()
		if now - self.chainStartTime >= 1:
			if self.mp < PlayerData.slashMpUsePerSecond:
				self.mp = 0
				self.slashEnd(x, y)
			else:
				self.mp = self.mp - PlayerData.slashMpUsePerSecond
				self.chainStartTime = now
		
	def slashEnd(self, x, y):
		if self.canAttack() == False:
			return
		
		self.chainsaw.slashEnd(x, y);