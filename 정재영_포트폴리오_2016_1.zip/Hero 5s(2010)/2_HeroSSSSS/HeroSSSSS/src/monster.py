#-*-coding: utf-8 -*-

#Import Modules
import os, pygame, re, copy, time, random
from pygame.locals import *
from pygame.compat import geterror
from lib import *
from playerData import PlayerData

class MonsterManager:	
	def __init__(self):
		fullname = os.path.join(data_dir, 'monster.txt')
		f = file(fullname)
		
		monDataList = []
		mondict = {}
		for line in f:
			line = line.strip()
			if len(line) == 0:
				continue
			# find =mon1=
			m = re.match(r'(=(?P<code>\w+)=)', line)
			if m != None:
				code = m.group('code')
				
				#등장은 code로 하니까 이거 등장시 이전거를 flush
				if 'code' in mondict:
					monsterdata = MonsterData(mondict)
					monDataList.append(monsterdata)
					mondict = {}
				mondict['code'] = code
				continue
			
			tokens = line.split(':')
			key = tokens.pop(0)
			data = tokens
			mondict[key] = data
			
		#이렇게 루프를 돌리면 맨 마지막꺼가 생성이 안된다 수동생성
		monsterdata = MonsterData(mondict)
		monDataList.append(monsterdata)
		
		#dict로 구성하기
		self.monsterDict = {}
		for data in monDataList:
			self.monsterDict[data.code] = data

	def create(self, code):
		return Monster(self.monsterDict[code])
	
	def random(self):
		monsterCodeList = self.monsterDict.keys()
		code = random.choice(monsterCodeList)
		return Monster(self.monsterDict[code])

class MonsterData:
	def __init__(self, mondict):
		self.code = mondict['code']
		self.name = mondict['name'][0]
		self.motion = mondict['motion']
		self.hit = mondict['hit']
		self.die = mondict['die']
		
		if 'hp' in mondict: 
			self.hp = mondict['hp'][0]
		else:
			self.hp = 10
		if 'attack' in mondict:
			self.attack = mondict['attack'][0]
		else:
			self.attack = 10	
		#read info
		#load sprite
		respath = os.path.join(data_dir, 'img/'+self.code)
		
		#motion
		motion = []
		for file in self.motion:
			path = os.path.join(respath, file)
			image, rect = load_image(path, -1)
			sprite = AniSprite(image, rect)
			motion.append(sprite)
		self.motion = motion
		
		#hit
		hit = []
		for file in self.hit:
			path = os.path.join(respath, file)
			image, rect = load_image(path, -1)
			sprite = AniSprite(image, rect)
			hit.append(sprite)
		self.hit = hit
		
		#die
		die = []
		for file in self.die:
			path = os.path.join(respath, file)
			image, rect = load_image(path, -1)
			sprite = AniSprite(image, rect)
			die.append(sprite)
		self.die = die 
	
class AniSprite:
	def __init__(self, image, rect):
		self.image = image
		self.rect = rect

class Monster:
	MotionState = 0
	HitState = 1
	DieState = 2
	NoneState = 3
	
	def canAttack(self):
		if self.getAlertLevel() == 5:
			return True
		else:
			return False
	
	def doAttack(self, player):
		now = time.time()
		if now - self.lastAttackTime > 1:
			'''attack!'''
			player.attacked(self.attack)
			self.lastAttackTime = now
	
	def stabbed(self):
		#갑옷은 여기에서 적절히 구현하기
		
		if self.getAlertLevel() == 4:
			self.hp = 0
		else:
			self.hp = self.hp - PlayerData.stabDamage
		
		self.state = Monster.HitState
			
	def slashed(self):
		#갑옷 적절히 구현하기
		self.hp = self.hp - PlayerData.slashDamagePerSecond / 60.0
		self.state = Monster.HitState
	
	def getMaxSize(self):
		initWidth = 53*2
		initHeight = 32.4*2
		dWidth = (-(50.0/1000.0)*self.pos + 50) * 2
		dHeight = dWidth * (63.0/103)
		width = initWidth + dWidth
		height = initHeight + dHeight
		return (int(width), int(height))
	
	def getSize(self):
		sprite = self.getSprite()
		maxSize = self.getMaxSize()
		maxWHscale = float(maxSize[0]) / float(maxSize[1])
		imgWHscale = sprite.rect.w / sprite.rect.h
		
		if maxWHscale >= imgWHscale:
			#세로로 늘리기
			height = maxSize[1]
			width = height / float(sprite.rect.h) * sprite.rect.w 
		else:
			#가로로 늘리기
			width = maxSize[0]
			height = width / float(sprite.rect.w) * sprite.rect.h
		return (int(width), int(height))
			
	
	def getPos(self):
		size = self.getSize()
		imgWidth = size[0]/2
		imgHeight = size[1]/2
		
		return (103-imgWidth, 63-imgHeight) 
	
	def __init__(self, monsterdata):
		self.data = monsterdata
		self.hp = int(monsterdata.hp)
		self.attack = int(monsterdata.attack)
		self.pos = 1000
		self.state = Monster.MotionState
		self.spriteCnt = 0
		
		self.lastAttackTime = time.time()
		
	def isNeedNextState(self):
		'''sprite cnt와 현재 state의 sprite리스트의 크기를 비교해서 다음 상태로 이동해야지 계산하는 함수'''
		spriteList = []
		if self.state == Monster.MotionState:
			spriteList = self.data.motion
		elif self.state == Monster.HitState:
			spriteList = self.data.hit
		elif self.state == Monster.DieState:
			spriteList = self.data.die
		
		range = 7
		index = self.spriteCnt / range
		if index < len(spriteList):
			return False
		else:
			self.spriteCnt = 0
			return True
	
		
	def update(self):
		self.pos = self.pos - 3
		if self.pos < 0:
			self.pos = 0
		self.spriteCnt = self.spriteCnt + 1
		
		if self.isNeedNextState() == True:
			#TODO FSM을 사용해서 적절한 상태 변경을 한다
			if self.state == Monster.MotionState:
				'''motion state에서는 할게 없다'''
				pass
			
			elif self.state == Monster.HitState:
				#TODO 몬스터나 상황에 따라서 state를 변경해야하는 경우 적절히 처리
				if self.hp > 0:
					self.state = Monster.MotionState
				else:
					self.state = Monster.DieState
				
				
			elif self.state == Monster.DieState:
				self.state = Monster.NoneState
			
			elif self.state == Monster.NoneState:
				pass
	
	def getSprite(self):
		spriteList = []
		if self.state == Monster.MotionState:
			spriteList = self.data.motion
		elif self.state == Monster.HitState:
			spriteList = self.data.hit
		elif self.state == Monster.DieState:
			spriteList = self.data.die
		
		range = 7
		index = self.spriteCnt / range
		if index < len(spriteList):
			sprite = spriteList[index]
		else:
			self.spriteCnt = 0
			sprite = spriteList[-1]
			
			if self.state == Monster.HitState:
				self.state = Monster.MotionState
		return sprite
		
	def getAlertLevel(self):
		if self.pos >= 600:
			return 1
		elif self.pos >= 300:
			return 2
		elif self.pos >= 100:
			return 3
		elif self.pos > 0:
			return 4
		else:
			return 5
			
	