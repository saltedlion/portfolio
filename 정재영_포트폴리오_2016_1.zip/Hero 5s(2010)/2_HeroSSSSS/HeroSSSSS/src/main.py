#-*-coding: utf-8 -*-

#Import Modules
import os, pygame, time
from pygame.locals import *
from pygame.compat import geterror
from lib import *
from player import *
from monster import *

if not pygame.font: print ('Warning, fonts disabled')
if not pygame.mixer: print ('Warning, sound disabled')


class Background(pygame.sprite.Sprite):
	def __init__(self, path, game):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image(path, -1)
		self.game = game
		
		#배경 그림은 풀사이즈로 리사이즈를 가한다
		self.image = pygame.transform.scale(self.image, (game.width, game.height))
		
	def update(self):
		pass

class GameState:
	def __init__(self, game):
		self.game = game
		self.end = False
		
	def isEnd(self):
		return self.end
	
	def pause(self):
		pass
	
	def resume(self):
		pass
		
class MenuState(GameState):
	def __init__(self, game):
		GameState.__init__(self, game)
		
		#load background
		self.background = Background('img/background/main.jpg', game)
		self.intro = load_sound('bgm/perkristian_doom-intro.ogg')
		
	def update(self):
		#Handle Input Events
		for event in pygame.event.get():
			if event.type == QUIT:
				self.end = True
			elif event.type == KEYDOWN and event.key == K_ESCAPE:
				self.end = True
			elif event.type == KEYDOWN and event.key == K_1:
				self.game.nextState = self.game.stageMgr.getAction('1.txt')
				
	
	def draw(self):
		allsprites = pygame.sprite.RenderPlain((self.background, ))
		allsprites.update()
		allsprites.draw(game.screen)
	
	def pause(self):
		self.intro.stop()
		
	def resume(self):
		self.intro.play(10000)

class MonsterPosition:
	def __init__(self, timepos, row, col, monCode):
		self.timepos = timepos
		self.row = row
		self.col = col
		self.monCode = monCode
		
class Stage():
	def __init__(self, name):
		#load stage file
		fullname = os.path.join(data_dir, 'stage/'+name)
		f = file(fullname)
		
		monPosList = []
		
		for line in f:
			line =  line.strip()
			if len(line) == 0 or line[0] == '#' :
				continue
			
			tokens = line.split(':')

			if len(tokens) == 1:
				tokens = line.split(' ')
				#time row col monster
				encounterTime = int(tokens[0])
				row = int(tokens[1])
				col = int(tokens[2])
				monCode = tokens[3]
				
				monPos = MonsterPosition(encounterTime, row, col, monCode)
				monPosList.append(monPos)
				
			if len(tokens) == 2:
				key = tokens[0]
				value = tokens[1]
				
				if key == 'bg':
					self.background = value
				elif key == 'bgm':
					self.bgm = value
				elif key == 'length':
					self.length = int(value)
			
		
		#현재시간 저장
		self.startTime = time.time()
		
		#monPosList를 사용가능한 모양의 자료구조로 변경하기
		monsterPosDict = {}
		for monPos in monPosList:
			timepos = monPos.timepos
			if (timepos in monsterPosDict) == True:
				monList = monsterPosDict[timepos]
				monList.append(monPos)
			else:
				#새로운 리스트를 생성한다
				monList = [monPos]
				monsterPosDict[timepos] = monList
		self.monsterPosDict = monsterPosDict
				
	def get(self):
		now = time.time()
		timepos = int(now - self.startTime)
		if (timepos in self.monsterPosDict) == True:
			monList = self.monsterPosDict[timepos]
			#목록에서 제거
			self.monsterPosDict.pop(timepos)
			return monList
		else:
			return []
		
	def isTimeover(self):
		interval = time.time() - self.startTime
		if interval >= self.length:
			return True
		else:
			return False
		

class Grid:
	'''0 1 2
	   3 4 5
	   6 7 8'''
	def __init__(self):
		self.grid = [[None, None, None],
					[None, None, None],
					[None, None, None]]
		
		self.monMgr = MonsterManager()
		'''
		self.grid[0][0] = monMgr.create('mon1')
		self.grid[0][1] = monMgr.create('mon2')
		self.grid[0][2] = monMgr.create('mon3')
		self.grid[1][0] = monMgr.create('mon4')
		self.grid[1][1] = monMgr.create('mon5')
		self.grid[1][2] = monMgr.create('mon6')
		self.grid[2][0] = monMgr.create('mon7')
		self.grid[2][1] = monMgr.create('mon8')
		self.grid[2][2] = monMgr.create('mon9')
		'''
	def get(self, row, col):
		return self.grid[row][col]
		
	def draw(self, surface):
		pygame.draw.rect(surface, (0, 0, 0), pygame.Rect(206, 0, 10, 404))
		pygame.draw.rect(surface, (0, 0, 0), pygame.Rect(422, 0, 10, 404))
		pygame.draw.rect(surface, (0, 0, 0), pygame.Rect(0, 126, 640, 10))
		pygame.draw.rect(surface, (0, 0, 0), pygame.Rect(0, 262, 640, 10))
		
		for y in range(3):
			for x in range(3):
				mon = self.grid[y][x]
				if mon == None:
					continue
				
				if mon.getAlertLevel() == 1:
					color = (0, 255, 0)
				elif mon.getAlertLevel() == 2:
					color = (255, 255, 0)
				elif mon.getAlertLevel() == 3:
					color = (255, 0, 0)
				elif mon.getAlertLevel() == 4 or mon.getAlertLevel() == 5:
					color = None
				
				#grid에 단계별 경고창 그리기
				baseX = 216*x
				baseY = 136*y

				#적절히 grid에 resize해서 몬스터 그리기
				sprite = mon.getSprite()
				img = pygame.transform.scale(sprite.image, mon.getSize())
				pos = mon.getPos()
				
				rect = pygame.Rect((pos[0]+baseX, pos[1]+baseY), mon.getSize())
				surface.blit(img, rect)
				
				if color != None:
					pygame.draw.rect(surface, color, pygame.Rect(baseX, baseY, 5, 126))
					pygame.draw.rect(surface, color, pygame.Rect(baseX, baseY, 206, 5))
					pygame.draw.rect(surface, color, pygame.Rect(baseX+201, baseY+0, 5, 126))
					pygame.draw.rect(surface, color, pygame.Rect(baseX, baseY+121, 206, 5))
		
	def update(self):
		for y in range(3):
			for x in range(3):
				mon = self.grid[y][x]
				if mon == None:
					continue
				
				mon.update()
				if mon.hp <= 0 and mon.state == 3:	#TODO 왜 Monster.NoneState는 안돌아가지?
					self.grid[y][x] = None
				else:
					'''아직 살아있는 경우'''
					if mon.canAttack() == True:
						mon.doAttack(self.player)
		#stage로부터 몬수터 정보를 얻어온다
		monList = self.stage.get()
		for monPos in monList:
			row = monPos.row
			col = monPos.col
			mon = self.monMgr.create(monPos.monCode)
			
			if self.grid[row][col] == None:
				self.grid[row][col] = mon
		
		
	def getRow(self, y):
		#세로로 몇번째 행인가
		row = -1
		if y <= 126:
			row = 0
		elif y >= 136 and y <= 262:
			row = 1
		elif y >= 272 and y <= 404:
			row = 2
		return row
	
	def getCol(self, x):
		#가로로 몇번째 열인가
		col = -1
		if x <= 206:
			col = 0
		elif x >= 216 and x <= 422:
			col = 1
		elif x >= 432 and x <= 640:
			col = 2
		return col
	
	def getPos(self, x, y):
		row = self.getRow(y)
		col = self.getCol(x)
		if row < 0 or col < 0:
			return -1
		else:
			return row*3 + col

class ActionState(GameState):
	def __init__(self, game, stagefile):
		GameState.__init__(self, game)
		self.loadStage(stagefile)
		
		self.grid = Grid()
		self.player = Player(self.grid)
		
		self.grid.player = self.player
		self.grid.stage = self.stage
		
		#이전 입력상태를 저장하기 위한 변수
		self.prevMousePos = (0, 0)
		self.mouseDownPos = (0, 0)
		self.prevMouseEvent = None
		self.mousePressed = False
		
	def update(self):
		#stage가 끝났는지 확인하기
		if self.stage.isTimeover() == True:
			self.game.nextState = self.game.stageMgr.getWin()
			return
		
		#Handle Input Events
		for event in pygame.event.get():
			if event.type == QUIT:
				self.end = True
			elif event.type == KEYDOWN and event.key == K_ESCAPE:
				self.end = True
			elif event.type == MOUSEBUTTONDOWN:
				x, y = pygame.mouse.get_pos()
				col = self.grid.getCol(x);
				row = self.grid.getRow(y);
				
				self.player.slashStart(x, y)
				
				#end
				self.prevMouseEvent = MOUSEBUTTONDOWN
				self.prevMousePos = pygame.mouse.get_pos()
				self.mouseDownPos = pygame.mouse.get_pos()
				self.mousePressed = True
				
			elif event.type == MOUSEMOTION:
				x, y = pygame.mouse.get_pos()
				
				if(self.mousePressed == True):
					if (x-self.mouseDownPos[0])**2 + (y-self.mouseDownPos[1])** 2 > 100:
						self.player.slashMove(x, y)
				
				#end
				self.prevMouseEvent = MOUSEMOTION
				self.prevMousePos = pygame.mouse.get_pos()
			
			
			elif event.type == MOUSEBUTTONUP:
				x, y = pygame.mouse.get_pos()
				col = self.grid.getCol(x);
				row = self.grid.getRow(y);
				
				#이전 이벤트로만 따질 경우 움직이면서 치면 명령이 씹힐 위험이 크다. 다른 방식으로
				#if self.prevMouseEvent == MOUSEBUTTONDOWN:
				if (x-self.mouseDownPos[0])**2 + (y-self.mouseDownPos[1])** 2 < 100:
					#주먹
					self.player.stab(row, col)
				else:
					self.player.slashEnd(x, y)
				
				
				#end
				self.prevMouseEvent = None
				self.prevMousePos = pygame.mouse.get_pos()
				self.mousePressed = False
				
			elif event.type == KEYDOWN and event.key == K_w:
				self.game.nextState = self.game.stageMgr.getWin()
		
		#time elapsed
		self.player.update()
		self.grid.update()
	
	def draw(self):
		face = self.player.getFace()
		allsprites = pygame.sprite.RenderPlain((self.background, face))
		allsprites.update()
		allsprites.draw(game.screen)
		
		self.grid.draw(game.screen)
		self.player.draw(game.screen)
		
		
	def pause(self):
		self.bgm.stop()
	
	def resume(self):
		self.bgm.play()
	
	def loadStage(self, stagefile):
		self.stage = Stage(stagefile)
		self.background = Background(self.stage.background, self.game)
		self.bgm = load_sound(self.stage.bgm)

	
class WinState(GameState):
	def __init__(self, game):
		GameState.__init__(self, game)
		self.background = Background('img/background/win.png', game)
	
	def update(self):
		#Handle Input Events
		for event in pygame.event.get():
			if event.type == QUIT:
				self.end = True
			elif event.type == KEYDOWN and event.key == K_ESCAPE:
				self.end = True
			elif event.type == MOUSEBUTTONDOWN:
				#change state to menu state
				self.game.nextState = self.game.stageMgr.getMenu()
				
	def draw(self):
		allsprites = pygame.sprite.RenderPlain((self.background, ))
		allsprites.update()
		allsprites.draw(game.screen)
	
	def pause(self):
		pass
	
	def resume(self):
		pass
	
class Monster:
	def __init__(self, monsterData):
		self.monsterData = monsterData

class MonsterData:
	def __init__(self, datafile):
		#parsing datafile
		self.hp = 100
		
			
class StateManager:
	def __init__(self, game):
		self.game = game
		self.menuState = None
		self.winState = None
		self.actionState = None
		
	def getMenu(self):
		if self.menuState == None:
			self.menuState = MenuState(self.game)
		return self.menuState
	
	def getWin(self):
		if self.winState == None:
			self.winState = WinState(self.game)
		return self.winState
	def getAction(self, stagefile):
		if self.actionState == None:
			self.actionState = ActionState(self.game, stagefile)
		else:
			self.actionState.loadStage(stagefile)
		return self.actionState

class Game:
	def __init__(self, width, height):
		self.width = width
		self.height = height
		
		pygame.init()
		self.screen = pygame.display.set_mode((width, height))
		pygame.display.set_caption('HeroSSSSS')
		pygame.mouse.set_visible(1)
		
		#set state
		self.stageMgr = StateManager(self)
		self.state = None
		#self.nextState = self.stageMgr.getMenu()
		self.nextState = self.stageMgr.getAction('1.txt')
		
		self.monsterMgr = MonsterManager()
	
	def run(self):
		clock = pygame.time.Clock()
		
		while(True):
			clock.tick(60)
			#check state change
			if(self.nextState != None):
				if(self.state != None):
					self.state.pause()
				self.nextState.resume()
				self.state = self.nextState
				self.nextState = None
				
			self.state.update()
			self.state.draw()
			
			#draw evetythong
			#self.screen.blit()
			pygame.display.flip()
			
			if(self.state.isEnd() == True):
				break
			
		pygame.quit()

if __name__ == '__main__':
	width = 640
	height = 480
	game = Game(width, height)
	game.run()