#-*-coding: utf-8 -*-

class PlayerData:
	playerMaxHp = 100
	playerMpPerSecond = 1
	
	#stab
	stabDamage = 10
	
	#slash
	slashDamagePerSecond = 10
	slashMpUsePerSecond = 10
	
	#smite
	smiteDmage = 20